// middleware/auth.js
const jwt = require('jsonwebtoken');

module.exports = function (req, res, next) {
  // 1. 获取标准的 Authorization 请求头
  const authHeader = req.header('Authorization');

  // 2. 检查是否存在
  if (!authHeader) {
    return res.status(401).json({ msg: 'No token, authorization denied' });
  }

  // 3. 去掉 "Bearer " 前缀，提取纯 Token
  const token = authHeader.split(' ')[1];

  // 4. 验证 token
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded.user;
    next();
  } catch (err) {
    res.status(401).json({ msg: 'Token is not valid' });
  }
};